def send_notification(user_id: int, message: str):
    # Placeholder for Firebase / SMS / Email
    print(f"[NOTIFY] User {user_id}: {message}")
