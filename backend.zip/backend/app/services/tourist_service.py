from sqlalchemy.orm import Session
from fastapi import HTTPException
from typing import List

from app.models.user import User
from app.core.websocket_manager import manager
from app.utils.helpers import hash_password


# --------------------------------
# Create Tourist
# --------------------------------
async def create_tourist(
    db: Session,
    email: str,
    password: str,
    full_name: str | None = None,
    phone: str | None = None,
    emergency_contact: str | None = None,
) -> User:

    # Check existing email
    existing = db.query(User).filter(User.email == email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    tourist = User(
        email=email,
        password=hash_password(password),
        role="tourist",
        full_name=full_name,
        phone=phone,
        emergency_contact=emergency_contact,
    )

    db.add(tourist)
    db.commit()
    db.refresh(tourist)

    # Real-time broadcast to dashboard
    await manager.broadcast({
        "type": "tourist_created",
        "data": {
            "id": tourist.id,
            "email": tourist.email,
            "full_name": tourist.full_name,
            "phone": tourist.phone,
            "emergency_contact": tourist.emergency_contact,
        }
    })

    return tourist


# --------------------------------
# Get All Tourists (Authority)
# --------------------------------
def get_all_tourists(db: Session) -> List[User]:
    return (
        db.query(User)
        .filter(User.role == "tourist")
        .order_by(User.id.desc())
        .all()
    )


# --------------------------------
# Get Tourist By ID
# --------------------------------
def get_tourist_by_id(db: Session, tourist_id: int) -> User:
    tourist = db.query(User).filter(
        User.id == tourist_id,
        User.role == "tourist"
    ).first()

    if not tourist:
        raise HTTPException(status_code=404, detail="Tourist not found")

    return tourist


# --------------------------------
# Update Tourist Profile
# --------------------------------
async def update_tourist_profile(
    db: Session,
    tourist_id: int,
    full_name: str,
    phone: str,
    emergency_contact: str,
) -> User:

    tourist = get_tourist_by_id(db, tourist_id)

    tourist.full_name = full_name
    tourist.phone = phone
    tourist.emergency_contact = emergency_contact

    db.commit()
    db.refresh(tourist)

    # Broadcast update
    await manager.broadcast({
        "type": "tourist_updated",
        "data": {
            "id": tourist.id,
            "full_name": tourist.full_name,
            "phone": tourist.phone,
            "emergency_contact": tourist.emergency_contact,
        }
    })

    return tourist
