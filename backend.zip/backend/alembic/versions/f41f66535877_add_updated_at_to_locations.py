from alembic import op
import sqlalchemy as sa


revision = "add_updated_at_locations"
down_revision = "add_iot_device_api_key"  # or your previous revision id
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "locations",
        sa.Column(
            "updated_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )


def downgrade():
    op.drop_column("locations", "updated_at")
