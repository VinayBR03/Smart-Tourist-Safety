// src/components/zones/ZoneForm.tsx

import { useState } from 'react';
import { Input } from '../common/Input';
import { Button } from '../common/Button';
import type {
  ZoneCreateCircularRequest,
  ZoneCreatePolygonRequest,
} from '../../types/zone';

// ─────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────

type ZoneMode = 'circular' | 'polygon';

interface ZoneFormProps {
  onSubmitCircular: (payload: ZoneCreateCircularRequest) => Promise<void>;
  onSubmitPolygon:  (payload: ZoneCreatePolygonRequest)  => Promise<void>;
  isSubmitting?:    boolean;
  onCancel?:        () => void;
}

// ─────────────────────────────────────────────
// Component
// ─────────────────────────────────────────────

export function ZoneForm({
  onSubmitCircular,
  onSubmitPolygon,
  isSubmitting = false,
  onCancel,
}: ZoneFormProps) {
  const [mode, setMode]         = useState<ZoneMode>('circular');
  const [name, setName]         = useState('');
  const [zoneType, setZoneType] = useState('');
  const [error, setError]       = useState<string | null>(null);

  // Circular fields
  const [lat, setLat]       = useState('');
  const [lng, setLng]       = useState('');
  const [radius, setRadius] = useState('');

  // Polygon fields (raw WKT-style: "lng,lat;lng,lat;...")
  const [coordsRaw, setCoordsRaw] = useState('');

  const handleSubmit = async () => {
    setError(null);
    try {
      if (mode === 'circular') {
        if (!name || !lat || !lng || !radius) {
          setError('All fields are required.');
          return;
        }
        await onSubmitCircular({
          name,
          zone_type: zoneType || undefined,
          center_latitude:  parseFloat(lat),
          center_longitude: parseFloat(lng),
          radius_meters:    parseFloat(radius),
        });
      } else {
        if (!name || !coordsRaw.trim()) {
          setError('Name and coordinates are required.');
          return;
        }
        const coordinates = coordsRaw
          .split(';')
          .map((pair) => {
            const [lngStr, latStr] = pair.split(',').map((s) => s.trim());
            return [parseFloat(lngStr), parseFloat(latStr)] as [number, number];
          })
          .filter(([a, b]) => !isNaN(a) && !isNaN(b));

        await onSubmitPolygon({ name, zone_type: zoneType || undefined, coordinates });
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to create zone.');
    }
  };

  return (
    <div className="space-y-5">
      {/* Mode toggle */}
      <div className="flex rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 text-sm">
        {(['circular', 'polygon'] as ZoneMode[]).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={[
              'flex-1 py-2 font-semibold transition-colors capitalize',
              mode === m
                ? 'bg-blue-600 text-white'
                : 'bg-white dark:bg-slate-900 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300',
            ].join(' ')}
          >
            {m}
          </button>
        ))}
      </div>

      <Input
        label="Zone Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="e.g. Heritage Quarter"
      />

      <Input
        label="Zone Type (optional)"
        value={zoneType}
        onChange={(e) => setZoneType(e.target.value)}
        placeholder="e.g. TOURIST, RESTRICTED"
      />

      {mode === 'circular' ? (
        <>
          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Center Latitude"
              type="number"
              value={lat}
              onChange={(e) => setLat(e.target.value)}
              placeholder="12.9716"
            />
            <Input
              label="Center Longitude"
              type="number"
              value={lng}
              onChange={(e) => setLng(e.target.value)}
              placeholder="77.5946"
            />
          </div>
          <Input
            label="Radius (meters)"
            type="number"
            value={radius}
            onChange={(e) => setRadius(e.target.value)}
            placeholder="500"
          />
        </>
      ) : (
        <div>
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5">
            Coordinates (lng,lat separated by semicolons)
          </label>
          <textarea
            value={coordsRaw}
            onChange={(e) => setCoordsRaw(e.target.value)}
            rows={4}
            placeholder="77.5946,12.9716;77.5950,12.9720;77.5955,12.9718;77.5946,12.9716"
            className={[
              'w-full px-3 py-2 rounded-xl text-sm font-mono',
              'border border-slate-200 dark:border-slate-700',
              'bg-white dark:bg-slate-900',
              'text-slate-800 dark:text-slate-200',
              'placeholder-slate-400',
              'focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent',
              'resize-none',
            ].join(' ')}
          />
          <p className="text-[10px] text-slate-400 mt-1">
            Polygon must be closed (first = last point). Min 4 points.
          </p>
        </div>
      )}

      {error && (
        <p className="text-xs text-red-500 dark:text-red-400">{error}</p>
      )}

      <div className="flex gap-3 pt-1">
        {onCancel && (
          <Button variant="ghost" onClick={onCancel} disabled={isSubmitting} fullWidth>
            Cancel
          </Button>
        )}
        <Button
          variant="primary"
          onClick={handleSubmit}
          loading={isSubmitting}
          fullWidth
        >
          Create Zone
        </Button>
      </div>
    </div>
  );
}