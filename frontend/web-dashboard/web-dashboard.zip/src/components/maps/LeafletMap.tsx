// src/components/maps/LeafletMap.tsx
//
// Wrapper for Leaflet. Leaflet CSS must be imported in global.css or main.tsx:
//   import 'leaflet/dist/leaflet.css'
//
// Uses react-leaflet. Add to package.json:
//   "react-leaflet": "^4.x", "leaflet": "^1.x"

import React, { useRef } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import type { Map as LeafletMapInstance } from 'leaflet';
import { MAP_DEFAULT_CENTER, MAP_DEFAULT_ZOOM } from '../../constants/config';
import { useIsDark } from '../../theme/useTheme';

// ─────────────────────────────────────────────
// Tile URLs
// ─────────────────────────────────────────────

const LIGHT_TILES = 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png';
const DARK_TILES  = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
const ATTRIBUTION = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com">CARTO</a>';

// ─────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────

interface LeafletMapProps {
  center?:      [number, number];
  zoom?:        number;
  height?:      string | number;
  className?:   string;
  onMapReady?:  (map: LeafletMapInstance) => void;
  children?:    React.ReactNode;
}

// ─────────────────────────────────────────────
// Component
// ─────────────────────────────────────────────

export function LeafletMap({
  center    = MAP_DEFAULT_CENTER,
  zoom      = MAP_DEFAULT_ZOOM,
  height    = 480,
  className = '',
  onMapReady,
  children,
}: LeafletMapProps) {
  const isDark   = useIsDark();
  const mapRef   = useRef<LeafletMapInstance | null>(null);

  const heightStyle = typeof height === 'number' ? `${height}px` : height;

  return (
    <div
      className={`rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 ${className}`}
      style={{ height: heightStyle }}
    >
      <MapContainer
        center={center}
        zoom={zoom}
        style={{ height: '100%', width: '100%' }}
        ref={mapRef}
        whenReady={() => {
          if (mapRef.current && onMapReady) onMapReady(mapRef.current);
        }}
        zoomControl={true}
        scrollWheelZoom={true}
      >
        <TileLayer
          key={isDark ? 'dark' : 'light'}
          attribution={ATTRIBUTION}
          url={isDark ? DARK_TILES : LIGHT_TILES}
          maxZoom={19}
        />
        {children}
      </MapContainer>
    </div>
  );
}