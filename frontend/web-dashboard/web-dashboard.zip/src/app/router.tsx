import { createBrowserRouter } from "react-router-dom"

import { DashboardLayout } from "../components/layout/DashboardLayout"
import { LoginLayout } from "../components/layout/LoginLayout"
import { ProtectedRoute } from "../components/common/ProtectedRoute"

import { LoginPage } from "../pages/auth/LoginPage"

import { DashboardPage } from "../pages/dashboard/DashboardPage"
import { ZonesPage } from "../pages/zones/ZonesPage"

import { IncidentListPage } from "../pages/incidents/IncidentListPage"
import { IncidentDetailPage } from "../pages/incidents/IncidentDetailPage"

import { DevicesPage } from "../pages/devices/DevicesPage"

import { HealthMonitoringPage } from "../pages/health/HealthMonitoringPage"

import { OperationsAnalyticsPage } from "../pages/analytics/OperationsAnalyticsPage"

import { NotificationsPage } from "../pages/notifications/NotificationsPage"

import { UsersPage } from "../pages/admin/UsersPage"
import { AuthoritiesPage } from "../pages/admin/AuthoritiesPage"
import { SystemAnalyticsPage } from "../pages/admin/SystemAnalyticsPage"

import { UserRole } from "../types/enums"



export const router = createBrowserRouter([

  /* =========================================================
  AUTH ROUTES
  ========================================================= */

  {
    path: "/login",
    element: <LoginLayout />,
    children: [
      {
        index: true,
        element: <LoginPage />
      }
    ]
  },


  /* =========================================================
  PROTECTED DASHBOARD
  ========================================================= */

  {
    path: "/",
    element: (
      <ProtectedRoute>
        <DashboardLayout />
      </ProtectedRoute>
    ),

    children: [

      /* =====================================================
      DASHBOARD
      ===================================================== */

      {
        index: true,
        element: <DashboardPage />
      },


      /* =====================================================
      ZONES
      ===================================================== */

      {
        path: "zones",
        element: <ZonesPage />
      },


      /* =====================================================
      INCIDENTS
      ===================================================== */

      {
        path: "incidents",
        element: <IncidentListPage />
      },

      {
        path: "incidents/:incidentId",
        element: <IncidentDetailPage />
      },


      /* =====================================================
      DEVICES
      ===================================================== */

      {
        path: "devices",
        element: <DevicesPage />
      },


      /* =====================================================
      HEALTH
      ===================================================== */

      {
        path: "health",
        element: <HealthMonitoringPage />
      },


      /* =====================================================
      ANALYTICS
      ===================================================== */

      {
        path: "analytics",
        element: <OperationsAnalyticsPage />
      },


      /* =====================================================
      NOTIFICATIONS
      ===================================================== */

      {
        path: "notifications",
        element: <NotificationsPage />
      },


      /* =====================================================
      ADMIN ONLY
      ===================================================== */

      {
        path: "admin/users",
        element: (
          <ProtectedRoute allowedRoles={[UserRole.ADMIN]}>
            <UsersPage />
          </ProtectedRoute>
        )
      },

      {
        path: "admin/authorities",
        element: (
          <ProtectedRoute allowedRoles={[UserRole.ADMIN]}>
            <AuthoritiesPage />
          </ProtectedRoute>
        )
      },

      {
        path: "admin/system-analytics",
        element: (
          <ProtectedRoute allowedRoles={[UserRole.ADMIN]}>
            <SystemAnalyticsPage />
          </ProtectedRoute>
        )
      }

    ]

  }

])