import { apiClient } from './client';
import type { DeviceSummary } from '@/types/api';

export const devicesApi = {
  listMine: () =>
    apiClient.get<DeviceSummary[]>('/devices').then((r) => r.data),

  getById: (deviceId: string) =>
    apiClient.get<DeviceSummary>(`/devices/${deviceId}`).then((r) => r.data),

  // Called when BLE connects — assigns wristband to current tourist
  assignToMe: (deviceId: string, touristId: number) =>
    apiClient
      .post(`/devices/${deviceId}/assign/${touristId}`)
      .then((r) => r.data)
      .catch((err) => {
        // 204 No Content is a success — axios may throw on empty body
        if (err?.response?.status === 204) return null;
        throw err;
      }),

  // Called when BLE disconnects — unassigns wristband from tourist
  unassign: (deviceId: string) =>
    apiClient
      .post(`/devices/${deviceId}/unassign`)
      .then((r) => r.data)
      .catch((err) => {
        if (err?.response?.status === 204) return null;
        throw err;
      }),
};